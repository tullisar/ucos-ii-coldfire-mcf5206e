/*******************************************************************************
 * file:   led.h
 * author: Robert Bartlett-Schneider 
 *         robert@savetherobots.org
 *         http://www.savetherobots.org
 *  
 * Contains information on the 7 x 5 LED array on the board
 *******************************************************************************/

#ifndef _LED_
#define _LED_

#define LED_BASE  0x40000000

#define LED_COL   LED_BASE+0x8
#define LED_ROW   LED_BASE+0x6

#define LED_COL_0   0x0000
#define LED_COL_1   0x0100
#define LED_COL_2   0x0200
#define LED_COL_3   0x0300
#define LED_COL_4   0x0400
#define LED_COL_OFF 0x0700

#define LED_ROW_0   0x0000
#define LED_ROW_1   0x0100 

#endif

