//------------------------------------------------------------------------ 
// ColdFire 5206E Specific Information
//------------------------------------------------------------------------

Test Hardware Info
------------------
MCF5206EC3 Rev1.3
ColdFire XCF5206EFT54 Processor
0J22G Mask
8MB DRAM Memory
P&E Rev C Wiggler

NOTE:  Some newer boards are shipping with the 2J22G mask.  CodeWarrior
has not been fully tested with this mask.

Debugger and Ports
------------------
The ColdFire boards generally use a P&E BDM connection through the parallel port for 
debugger communication. Input and output are done in two ways:

a) Console I/O using MetroTRK console mechanism via BDM
b) Using the UART on the board

The stationery contains the libraries necessary for a basic functioning setup.

NOTE: The debugger uses the Illegal Instruction Vector to stop.
A small subroutine is written at the location VBR+0x408-VBR+0x40B
to handle the exception.  The Illegal Instruction Vector in
the vector table at VBR+0x10 is then pointed to it.  When the
debugger encounters an illegal instruction, it jumps to this 
subroutine, which ends with an RTE, then exits.
Do not overwrite this area of memory otherwise the debugger may not exit properly.


Libraries
---------
There are several different libraries used for the ColdFire stationery:
    
- C_4i_CF_Runtime.a
  This is the C Runtime library that contains the entry point __start for RAM targets.
  ROM targets start out in the reset code, and it eventually jumps to __start.

- Cpp_4i_CF_Runtime.a
  This is the C++ runtime library, and needs to be included _instead_ of the C Runtime
  library if the project uses C++/EC++.  
  
- fp_coldfire.o
  This is the floating point emulation library that is called by the compiler.
  You do not need to make explicit calls to the library in order to have floating
  point support.

- C_4i_CF_MSL.a
  This is the standard C library, and has to be included whenever you make standard
  C library calls.

- C_TRK_4i_CF_MSL.a
  Include this library when using console I/O. This version includes the necessary MetroTRK
  infrastructure to use the TRK console for I/O.  

- C++_4i_CF_MSL.a
  This is the standard C++ library, and has to be included whenever you make C++ library
  calls.
  
- EC++_4i_CF_MSL.a
  This is the EC++ library, and has to be included whenever you make EC++ library calls.
    
- UART_SBC_5206e_Aux.a
  This is the UART library for the ColdFire 5206e C3 board, and has to be included
  whenever the code does printfs, or couts using the UART on the board.
  
UART Output
-----------
The MSL C library sets UART output to 19200 baud. You can change this by editing the 
definition of UART_CONSOLE_BAUD_RATE in the file uart_console_config.h

//------------------------------------------------------------------------
//	Overview
//------------------------------------------------------------------------

This project stationery is designed to get you up and running
quickly with CodeWarrior for Embedded 68k/ColdFire.  It is set up
for a particular evaluation board, but can be easily modified
to target custom hardware.  The hardware specific changes that
you may need to make include hardware initialization code, 
UART driver, flash programming code, and possibly the linker
command file for memory map issues.

The project has the following four targets:


Console I/O Version
-------------------
This target uses the MetroTRK console mechanism for I/O.
The settings are similar to the debug target.

Debug Version
-------------
This target does not do any hardware initialization or generate romable code.
It is designed to get you started coding fast and debugging your code in RAM.

Release Version
---------------
This is the release version that is compiled with full optimizations
turned on and A6 stack frames turned off. It is designed to be used
as a guideline in generating optimized release code.

ROM Version
-----------
This target is set up to make a romable image.  ColdFire ROM examples
include exception vectors and are linked in such a way that they 
will boot from reset and copy the specified sections from ROM to RAM.
They include a default interrupt handler function which can easily be
modified to suit your needs, and output an S-Record file which can
be used by various flash programmers to burn the image to ROM.  This 
target can also be used to debug the image once it is in ROM.  It is
compiled with full optimizations on.  If you wish to do debugging
with this target, however, they should be turned off again.



//------------------------------------------------------------------------
//	Getting Started
//------------------------------------------------------------------------

Most of the target settings are already configured for you, but you
will need to configure the debugger settings.  From the Edit menu,
select Debug Version Settings... (Alt+F7). Select the E68k Target
Settings preference panel from left column.  Select the protocol and related
options that you want to use for debugging.  We recommend that you make
sure the project is working properly on your hardware before you begin
adding your own code.  Make sure your target has power and is connected
with the selected debug protocol.  Select Enable Debugger from the 
Project menu and then select Debug.  If everything is working properly,
the debugger window should come up and be stopped at main().  If there
is a problem, please consult Targeting_Embedded68k.pdf for more
information on your selected debug protocol.  

The Debug Version target simply prints 'Hello World...' to the
UART and then goes into an infinite while loop. Some targets will
end in the runtime with an illegal instruction exception. If there 
are no ISR's installed for this target, the code will either exit after the
illegal instruction exception which is expected by the debugger as the 
end of the program, or it will branch to the location of the illegal
instruction interrupt vector, depending on your debug protocol.

Images may be burned to ROM using either a flash programmer or, on Dragonball 
targets, the built-in software flash routine.  Once the image is in ROM, the 
code can be debugged with the ROM Version target.  Make sure to set the debugger
settings for this target as well. If all goes as expected, the following should
appear in the terminal program window:

Hello World MW in C/C++/EC++

//------------------------------------------------------------------------
//	Adding your own code
//------------------------------------------------------------------------

Once everything is working as expected, you can begin adding your own code
to the project.  Keep in mind that we provide this as an example of how to
get up and running quickly with CodeWarrior.  There are certainly other 
ways to handle interrupts and set up your linker command file.  Feel free
to modify any of the source provided. 


//------------------------------------------------------------------------
//	Contacting Metrowerks
//------------------------------------------------------------------------

For bug reports, technical questions, and suggestions, please use the
forms in the Release Notes folder on the CD, and send them to:

emb_support@metrowerks.com   : For bug reports.
cw_suggestion@metrowerks.com : For suggestions.


