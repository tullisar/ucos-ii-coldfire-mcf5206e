/*
 * File:		main.c
 * Purpose:		sample program
 *
 */

#include <iostream>

int main()
{

	cout << "Hello World in EC++\n\r" << endl;
	
	return 0;
}