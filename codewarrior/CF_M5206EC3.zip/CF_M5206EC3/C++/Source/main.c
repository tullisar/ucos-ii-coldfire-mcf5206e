/*
 * File:		main.c
 * Purpose:		sample program
 *
 */

#include <iostream>

using namespace std;

int main()
{
	cout << "Hello World in C++\n\r" << endl;
	
	while(1);	// Idle
	
	return 0;
}
