==================================================================
Installing ROM Targets for ColdFire 5206e boards
==================================================================

WARNING:  Flashing the ROM stationery will overwrite dbug
or any other applications you may have installed in the Flash!

==================================================================
Jumper Settings for ColdFire 5206e
==================================================================

This code was tested with the JP2 Jumper set between pins 1 and 2.
This will enable the board to boot from address 0xffe00000, which is
what the ROM stationery is built to run from.

==================================================================
Burning ROM Stationery to flash
==================================================================

This process requires that you use the P&E ColdFire Flash Programmer
software that is distributed by P&E.

1) Connect the ColdFire 5206e board to your host PC using the P&E 
BDM connector through the parallel port. 

2) Load the Stationery project and compile. This will produce
a file called <myboard>.S19. It is important that the S-Record file 
have lines no longer than 80 characters.  Some flash programmers may
report timeout errors if the S-Record lines are too long. 

3) Exit CodeWarrior to free parallel port for P&E ColdFire Flash
Programmer.  If you are using CodeWarrior to read this file, you
might want to print it out or open it in another text editor first,
as it will go away with the IDE. 

4) Power the board on.

5) Launch the P&E ColdFire Flash Programmer.

6) Select the appropriate Programming Algorithm to use. For the CF5206eC3 board,
the correct flash algorithm file is Am_004tw.cfp which corresponds to the 
AM29LV004T flash chip.

7) Enter ffe00000 as the base address.

8) Select the menu item File\Specify S Record.
Choose the ROM stationery S-record file that was just built for the CF5206eC3.

9) Select the menu item Program\Erase Module. The Status Window should print out
"Erasing". Wait until it prints out "Module has been erased" before continuing
to the next step.

10) Select the menu item Program\Program Module. The Status Window should print out
"Programming Address $<address>". Wait until it prints out the message 
"Programmed." before continuing to the next step.

11) At this point, the ROM Stationery should be in flash. Exit from the P&E
ColdFire Flash Programmer, turn the board off, and disconnect the BDM 
connector from the board.

12) Power the board on.  

13) The ROM output varies depending on which board you are using.
Set up a serial communications program such as HyperTerminal for
19200 baud,N,8,1 and No Flow Control.  Plug the serial cable
into the AUXILARY port on the board, and power on.  A message
from your ROM target should appear on the terminal. If it does not, try 
resetting the board and make sure the BDM is not connected to the board.
