/*
 * File:		main.c
 * Purpose:		sample program
 *
 */

#include <stdio.h>

int main()
{
	printf("Hello World MW in C\n\r");
	
	fflush(stdout);
	
	while(1);	// Idle
	
	return 0;
}
